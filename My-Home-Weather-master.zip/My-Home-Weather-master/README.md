# My-Home-Weather
This App connects to Sarmalink service and offers a native Android interface to read your smart thermoter.
