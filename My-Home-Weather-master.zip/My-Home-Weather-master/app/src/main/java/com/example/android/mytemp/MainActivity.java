package com.example.android.mytemp;

import android.app.LoaderManager;
import android.content.Loader;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.db.chart.model.LineSet;
import com.db.chart.renderer.AxisRenderer;
import com.db.chart.view.LineChartView;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Formatter;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<TemperatureData> {

    private TextView tempTextView;
    private TextView timestampTextView;
    private TextView deviceNameTextView;

    /**
     * Constant value for the temperature loader ID.
     * This really only comes into play if you're using multiple loaders.
     */
    private static final int TEMPERATURE_LOADER_ID = 1;

    private static final String LOG_TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.d(LOG_TAG, "onCreate: ");
        setContentView(R.layout.activity_main);

        tempTextView = (TextView) findViewById(R.id.temperature_text_view);
        timestampTextView = (TextView) findViewById(R.id.timestamp_text_view);
        deviceNameTextView = (TextView) findViewById(R.id.name_text_view);

        // Get a reference to the LoaderManager, in order to interact with loaders.
        LoaderManager loaderManager = getLoaderManager();

        // Initialize the loader. Pass in the int ID constant defined above and pass in null for
        // the bundle. Pass in this activity for the LoaderCallbacks parameter (which is valid
        // because this activity implements the LoaderCallbacks interface).
        loaderManager.initLoader(TEMPERATURE_LOADER_ID, null, this);


    }

    @Override
    public Loader<TemperatureData> onCreateLoader(int id, Bundle args) {

        Log.d(LOG_TAG, "onCreateLoader: " + args);
        // Create a new loader for the given URL
        return new DataLoader(this, null);
    }

    @Override
    public void onLoadFinished(Loader<TemperatureData> loader, TemperatureData data) {

        if (data != null) {

            Log.d(LOG_TAG, "onLoadFinished: " + data);
            tempTextView.setText(data.getTemperature() + "°C");
            timestampTextView.setText(data.getCurrentTime());
            deviceNameTextView.setText(data.getDeviceName());


            //plot 24h temperature history on chart
            if (data.getTemperature24hLineSet() != null) {

                LineChartView lineChartViewTempHist = (LineChartView) findViewById(R.id.linechart);

                lineChartViewTempHist.reset();

                LineSet dataset = data.getTemperature24hLineSet();
                dataset.setSmooth(true);

                //Grid
                Paint gridPaint = new Paint(R.color.colorAccent);
                gridPaint.setStyle(Paint.Style.FILL);
                gridPaint.setPathEffect(new DashPathEffect(new float[]{10, 10}, 0));
                lineChartViewTempHist.setGrid(10, 10, gridPaint);

                lineChartViewTempHist.addData(dataset);

                float minValue = dataset.getMin().getValue();
                float maxValue = dataset.getMax().getValue();

                minValue = minValue - minValue * 0.1f;
                maxValue = maxValue * 1.1f;
                float step = (maxValue - minValue) / 5;
                lineChartViewTempHist.setAxisBorderValues(minValue, maxValue, step);
                lineChartViewTempHist.setAxisLabelsSpacing(3);

                lineChartViewTempHist.setXLabels(AxisRenderer.LabelPosition.NONE);
                DecimalFormat format = new DecimalFormat("##.#");
                lineChartViewTempHist.setLabelsFormat(format);
                lineChartViewTempHist.show();
            }


        }

    }

    @Override
    public void onLoaderReset(Loader<TemperatureData> loader) {

        Log.d(LOG_TAG, "onLoaderReset: ");


    }
}
